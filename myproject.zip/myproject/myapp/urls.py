from django.urls import path
from .views import *

urlpatterns = [
    path('user_signup_view/',User_Signup_View,name='user_signup_view'),
    path('',User_Signin_View,name='user_signin_view'),

    path('home_page_view/',homepage,name='home_page_view'),
    path('blog_details/<int:id>/',blog_details,name='blog_details'),
    path('create_blog_view/',create_blog,name='create_blog'),
    path('edit_blog/<int:id>/',edit_blog,name='edit_blog'),
    path('delete_blog/<int:id>/',delete_blog,name='delete_blog'),

    path('user_signout_view/',User_Signout_View,name='user_signout_view')
]