from django.shortcuts import render,redirect
from myapp.models import *
from myapp.EmailBackend import EmailBackEnd
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse


def User_Signup_View(request):
    if request.method == 'GET':
        return render(request,'signup.html')
    else:
        req_username = request.POST.get('username')
        req_email = request.POST.get('email')
        req_password = request.POST.get('password1')
        
        user_obj = CustomUser.objects.create(
            user_type = 2,
            username=req_username,
            email=req_email,
        )
        user_obj.set_password(req_password)
        user_obj.save()

        return redirect('user_signin_view')
    

def User_Signin_View(request):
    if request.method == 'GET':
        return render(request,'signin.html')
    elif request.method == 'POST':
        req_email = request.POST.get('email')
        req_password = request.POST.get('password')

        user=EmailBackEnd.authenticate(request,username=req_email,password=req_password)
        if user:
            login(request,user)
            return redirect('home_page_view')
        else:
            return redirect('user_signin_view')
    else:
        return redirect('user_signin_view')
    


@login_required(login_url='user_signin_view')
def homepage(request):
    userobj = request.user
    data = MyBlog.objects.all().order_by('-id')
    context = {
        'userobj':userobj,
        'data':data,
        'usercount':CustomUser.objects.all().count()
    }
    return render(request,'bloglist.html',context)


@login_required(login_url='user_signin_view')
def blog_details(request,id):
    userobj = request.user
    user_flage = False

    blog = MyBlog.objects.filter(id=id).first()
    
    all_blog = MyBlog.objects.filter(user=userobj).order_by('-id').exclude(id=blog.id)
    if userobj == blog.user:
        user_flage = True
    context = {
        'userobj':userobj,
        'user_flage':user_flage,
        'blog':blog,
        'all_blog':all_blog if all_blog else None
    }
    return render(request,'blog_detail.html',context)


@login_required(login_url='user_signin_view')
def create_blog(request):
    userobj = request.user
    if request.method == 'GET':
        data = MyBlog.objects.all()
        context = {
            'userobj':userobj,
            'data':data
        }
        return render(request,'create_blog.html',context)
    elif request.method == 'POST':
        req_title = request.POST.get('title')
        req_content = request.POST.get('content')

        blog = MyBlog(
            user = userobj,
            title = req_title,
            content = req_content
        )
        blog.save()
        return redirect('home_page_view')


@login_required(login_url='user_signin_view')
def edit_blog(request,id):
    userobj = request.user
    if request.method == 'GET':
        blog = MyBlog.objects.filter(id=id).first()
        context = {
            'userobj':userobj,
            'blog':blog
        }
        return render(request,'editblog.html',context)
    elif request.method == 'POST':
        req_title = request.POST.get('title')
        req_content = request.POST.get('content')

        MyBlog.objects.filter(id=id).update(
            user = userobj,
            title = req_title,
            content = req_content
        )
        return redirect('home_page_view')


def delete_blog(request,id):
    blog = MyBlog.objects.filter(id=id).first()
    blog.delete()
    return redirect('home_page_view')


def User_Signout_View(request):
    logout(request)
    return redirect('user_signin_view')